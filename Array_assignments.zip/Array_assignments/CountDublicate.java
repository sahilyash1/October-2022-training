package Array_assignments;

public class CountDublicate {
public static void main(String[] args) {
		
		int[] a = {35, 14, 25, 35, 8, 12, 35, 14, 55, 35, 36};
		
		for (int i = 0; i < a.length; i++) {
			int count=1;
			
			for(int j=i+1;j<a.length;j++)
			{
				
				if(a[i]==0)
					continue;
				if(a[i]==a[j])
				{
					count++;
				
					a[j]=0;
				}
				
				
			}
			if(count>1)
				System.out.println("Count :- "+a[i]+" "+"Number :- "+count);
			
		}
		
	}

}
