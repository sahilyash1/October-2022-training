package Array_assignments;

public class EvenOddPerfectAndPrime {
	public static void main(String[] args) {

		int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 10, 11, 17, 19, 21, 28 };

		int count = 0;
		int count1 = 0;
		int count2 = 0;
		int perfect = 0;
		int prime = 1;

		for (int i = 0; i < arr.length; i++) {

			if (arr[i] % 2 == 0) {
				count++;
			}
			if (arr[i] % 2 != 0) {
				count1++;
			}

			for (int j = 2; j <= arr.length - 1; j++) {

				if (arr[i] % j == 0) {
					prime++;
				}

			}

			if (prime == 1) {

				count2++;

			}

			int sum = 0;
			int num = arr[i];
			for (int k = 1; k < num; k++) {

				if (num % k == 0) {

					sum = sum + k;

				}

			}

			if (sum == num) {

				perfect++;

			}

		}

		System.out.println("Count of Even Numbers is " + count);
		System.out.println("Count of Odd Numbers is " + count1);
		System.out.println("Count of Prime Numbers is " + count2);
		System.out.println("Count of Perfect Numbers is " + perfect);

	}

}
