package Array_assignments;

public class Pythagoras {
	public static void main(String[] args) {
		int arr[] = { 3, 4, 5, 6, 8, 10 };

		for (int i = 0; i < arr.length - 2; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				if ((arr[i] * arr[i]) + (arr[j] * arr[j]) == (arr[i + 2] * arr[i + 2])) {
					System.out.println(arr[i] + " " + arr[i + 1] + " " + arr[i + 2] + " satisfies pythgoras theorem");
				}
			}
		}
	}


}
