package Array_assignments;

public class SortByUnitPlace {
	public static void main(String[] args)
	  {
	        int array[] = { 10, 2, 3, 41, 12, 13, 19, 81, 9 };
	        
	        for (int i = 0; i < array.length - 1; i++)
	        {
	            for (int j = i + 1; j < array.length; j++)
	            {
	                int temp1 = array[i] % 10;
	                int temp2 = array[j] % 10;
	                if (temp1 > temp2) {
	                    int var = array[i];
	                    array[i] = array[j];
	                    array[j] = var;
	                }
	            }
	            
	            System.out.println(array[i]);
	        }
	  }   

}
