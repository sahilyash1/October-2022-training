package Array_assignments;

public class SortBylength {
	public static void main(String[] args)
    {
         String arr[] = { "My", "name", "is","Sahil","And","from Punjab"};

               String temp;

          for (int i = 0; i < arr.length; i++)
           {                
                for (int j = i+1; j < arr.length; j++)
                {
                    if (arr[i].length() > arr[j].length())
                    {
                       temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                   }
               }
                System.out.println(arr[i]);
           }
    }

}
