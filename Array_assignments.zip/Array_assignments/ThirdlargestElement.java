package Array_assignments;

public class ThirdlargestElement {


	public static void main(String args[]){
		   int temp, size;
		   int a[] = {12, 15, 23, 66, 92, 60};
		   size = a.length;
		   
		   for(int i = 0; i<size; i++ ){
		      for(int j = i+1; j<size; j++){
		         if(a[i]>a[j]){
		            temp = a[i];
		            a[i] = a[j];
		            a[j] = temp;
		         }
		      }
		   }
		   System.out.println("Third largest number is:: "+a[size-3]);
		   }
}
