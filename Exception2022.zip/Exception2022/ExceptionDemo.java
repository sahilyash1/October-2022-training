package Day8;

import java.io.FileInputStream;

class ExceptionDemo
{
		public static void main(String args[])
		{
			FileInputStream f=new FileInputStream("D:/xyz.txt");
			Class.forName("com.mysql.jdbc.driver");
			
		}
}
