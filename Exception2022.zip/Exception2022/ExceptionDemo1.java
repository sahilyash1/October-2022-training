package Day8;

class ExceptionDemo1
{
	public static void main(String[] args)
	{
		System.out.println("Yash");
		System.out.println("Technologies");
		System.out.println("jaynam");
		System.out.println(100/0);//runtime exception or unchecked exception
		System.out.println("Bye");
	}
}
