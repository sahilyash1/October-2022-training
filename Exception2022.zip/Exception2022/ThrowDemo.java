package Day8;

import java.util.Scanner;
class VoteEligiblity  extends RuntimeException
{
	VoteEligiblity(String s)
	{
		super(s);
	}
}

class ThrowDemo
{
	public static void main(String[] args)
	{
			Scanner s=new Scanner(System.in);
			System.out.println("Enter your age");
			int age=s.nextInt();
			try
			{
			if(age<18)
			{
				throw new VoteEligiblity("You are not eligible for voting");
				//System.out.println("after throw");
			}
			else
			{
				System.out.println("You can vote");
			}
			
			}
			catch(VoteEligiblity e)
			{
				System.out.println(e.getMessage());
			}
			System.out.println("Normal Termination");
			
	}
}

