package OOPS_assignmentsQuestion11;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainClass {
	public class main {

		public static void main(String[] args) throws ParseException {
			
			
			String birth = "09/09/1998";
			Date dob = new SimpleDateFormat("dd/MM/yyyy").parse(birth);
			String join = "04/07/2016";
			Date doj = new SimpleDateFormat("dd/MM/yyyy").parse(join);
			
			Employee e=new Employee(101, "sahil khatri", 25000.00, "Amritsar", dob, doj);
			
			System.out.println("Employee Details:- "+e.toString());

		}


	}
}
