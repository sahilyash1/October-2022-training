package OOPS_assingmentsQuestion2;

public interface Shape {
	public double area();

}
