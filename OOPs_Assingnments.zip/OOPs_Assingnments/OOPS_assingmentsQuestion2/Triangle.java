package OOPS_assingmentsQuestion2;

import java.util.Scanner;

public class Triangle implements Shape {
	int x1, y1, x2, y2, x3,y3;
    double A, B, C;

	@Override
	public double area() {
	    Scanner sc=new Scanner(System.in);
	    
	    System.out.println("Enter the co-ordinate of x1 and y1");
	    x1=sc.nextInt();
	    y1=sc.nextInt();
	    
	    System.out.println("Enter the co-ordinate of x2 and y2");
	    x2=sc.nextInt();
	    y2=sc.nextInt();
	    
	    System.out.println("Enter the co-ordinate of x3 and y3");
	    x3=sc.nextInt();
	    y3=sc.nextInt();



	   double d1=(x2-x1)*(x2-x1)+(y2-y1)*(y2-y1);
	    A=Math.sqrt(d1);
	    
	    double d2=(x3-x2)*(x3-x2)+(y3-y2)*(y3-y2);
	    B=Math.sqrt(d2);
	    
	    double d3=(x3-x1)*(x3-x1)+(y3-y1)*(y3-y1);
	    C=Math.sqrt(d3);
	    
	    double s=((A+B+C)/2);//Perimeter of Triagle 
	  
	    
	double area=s*(s-A)*(s-B)*(s-C);
	    
	    return area;
	}



	public static void main(String[] args) {
	    Shape triangle=new Triangle();
	    System.out.println("Area of Triangle "+triangle.area());
	}


	
	
	
	
	
	

}
