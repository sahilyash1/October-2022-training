package OOPS_assingmentsQuestion3;

public class Main {
	public static void main(String[] args) 
	  {
		  System.out.println(" Enter the branch details");
		  //creating multiple object of brances
		  
		  Branch   b1 = new Branch(01,"Axis","Amritsar" );
		  System.out.println("Enter the details of brnach b1");
		  System.out.println(b1);
		  
		  Branch   b2 = new Branch(02,"HDFC","Jalandhar" );
		  System.out.println("Enter the details of brnach b1");
		  System.out.println(b2);
		  
		  Branch   b3 = new Branch(03,"PNB","Batala" );
		  System.out.println("Enter the details of brnach b1");
		  System.out.println(b3);
		  
		System.out.println("Enter customer details");	
		
		Customer c1 = new Customer(21,00004546,"Sahil khatri", "Amritsar","14/11/94","10/08/19", b1);
		//creating multiple objects of customers
		System.out.println("Enter the details of customer c1 ");
		System.out.println(c1);
		
		Customer c2 = new Customer(22,00003322,"Aman laksh", "Dhar","14/10/97","01/11/21", b2);
		System.out.println("\"Enter the details of customer c1");
		System.out.println(c2);
		
		Customer c3 = new Customer(23,6677,"raghav", "saharanpur","03/04/2000","02/08/2019", b3);
		System.out.println("\"Enter the details of customer c1");
		System.out.println(c3);
		
		
		System.out.println("all the details of Customer_Account_Statement");
		
		Customer_Account_Statement cas1 = new Customer_Account_Statement(301,c1, 30000, 600, "22/06/21");
		System.out.println("details of Customer_Account_Statement cas1");
		System.out.println(cas1);
		
		Customer_Account_Statement cas2 = new Customer_Account_Statement(302,c2, 6000, 500, "24/07/20");
		System.out.println("details of Customer_Account_Statement cas2");
		System.out.println(cas2);
		
		Customer_Account_Statement cas3 = new Customer_Account_Statement(303,c3, 8000, 300, "20/08/21");
		System.out.println("details of Customer_Account_Statement cas3");
		System.out.println(cas3);
	  }


}
