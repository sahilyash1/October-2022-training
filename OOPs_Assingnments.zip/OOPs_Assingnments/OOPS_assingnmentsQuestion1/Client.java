package OOPS_assingnmentsQuestion1;

import java.util.Date;

public class Client {

	public static void main(String[] args) {
		Department[] dept=new Department[2];
		dept[0]=new Department("D101","IT Department");
		dept[1]=new Department("D102","HR Department");

		Employee emp=new Employee(101,"Sahil Khatri","Amritsar","14/11/1998",20000,"09/03/1992",
				"Indore",dept[1],3594888,"sahil@gmail.com");
		
		System.out.println("Employee Details are: ");
		emp.printEmployeeDetails();
		
		Customer customer=new Customer(1001,"sa","Indore", "12/10/1997","14/12/1995", "Indore",
				98374743,"sa@gmail.com");
		
	
		System.out.println("\nCustomer Details are: ");
		customer.printCustomerDetails();
	}

}
