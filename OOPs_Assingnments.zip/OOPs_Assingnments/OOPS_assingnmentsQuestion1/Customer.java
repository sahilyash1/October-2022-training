package OOPS_assingnmentsQuestion1;

import java.util.Date;

public class Customer extends Person {
	private String date_registration;
	private String delivery_address;
	private int contact_no;
	private String email_id;
	
	
	
	
	
	public Customer(int pid, String pname, String paddress, String dob, String date_registration, String delivery_address,
			int contact_no, String email_id) {
		super(pid, pname, paddress, dob);
		this.date_registration = date_registration;
		this.delivery_address = delivery_address;
		this.contact_no = contact_no;
		this.email_id = email_id;
	}
	public String getDate_registration() {
		return date_registration;
	}
	public void setDate_registration(String date_registration) {
		this.date_registration = date_registration;
	}
	public String getDelivery_address() {
		return delivery_address;
	}
	public void setDelivery_address(String delivery_address) {
		this.delivery_address = delivery_address;
	}
	public int getContact_no() {
		return contact_no;
	}
	public void setContact_no(int contact_no) {
		this.contact_no = contact_no;
	}
	public String getEmail_id() {
		return email_id;
	}
		
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	
	
	public void printCustomerDetails() 
	{
		 System.out.println("Customer Id: " + Pid + "\nCustomer Name: " + pname + "\nAddress: " + paddress + "\nDOB: "
	                + dob + "\nRegistration Date: " + delivery_address + "\nDelivery Address: " + delivery_address
	                + "\nContactNo: " + contact_no + "\nEmail-Id: " + email_id);
	    }
	}
	

	

