package OOPS_assingnmentsQuestion1;

public class Department {
	private String deptid;
	private String dname;
	public String getDeptid() {
		return deptid;
	}
	public void setDeptid(String deptid) {
		this.deptid = deptid;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public Department(String string, String dname) {
		super();
		this.deptid = string;
		this.dname = dname;
	}

}
