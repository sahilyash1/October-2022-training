package OOPS_assingnmentsQuestion1;

import java.util.Date;

public class Employee extends Person {
	
	private int salary;
	private String date_of_joining;
	private String base_location;
	private Department deptobj;
	private int contactno;
	private String emailid;
	
	
	

	public Employee(int pid, String pname, String paddress, String string, int salary, String date_of_joining,
			String base_location, Department dept, int contactno, String emailid) {
		super(pid, pname, paddress, string);
		this.salary = salary;
		this.date_of_joining = date_of_joining;
		this.base_location = base_location;
		this.deptobj = dept;
		this.contactno = contactno;
		this.emailid = emailid;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getDate_of_joining() {
		return date_of_joining;
	}
	public void setDate_of_joining(String date_of_joining) {
		this.date_of_joining = date_of_joining;
	}
	public String getBase_location() {
		return base_location;
	}
	public void setBase_location(String base_location) {
		this.base_location = base_location;
	}
	public Department getDeptobj() {
		return deptobj;
	}
	public void setDeptobj(Department deptobj) {
		this.deptobj = deptobj;
	}
	public int getContactno() {
		return contactno;
	}
	public void setContactno(int contactno) {
		this.contactno = contactno;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}


	void  printEmployeeDetails() {
		System.out.println("Employee ID : "+Pid+"\nEmployee Name: "+pname+"\nAddress: "+paddress+"\nDOB: "+dob+
                "\nSalary: "+salary+"\nDate of Joining: "+date_of_joining+"\nBase Location: "+base_location+
                "\nDepartment: "+deptobj+"\nContact Number: "+contactno+"\nEmail-Id: "+emailid);
    }
	

}


