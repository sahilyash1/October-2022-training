package OOPS_assingnmentsQuestion1;

import java.util.Date;

public class Person {
	protected int Pid;
	protected String pname; 
	protected String paddress;
	
	public int getPid() {
		return Pid;
	}


	public void setPid(int pid) {
		Pid = pid;
	}


	public String getPname() {
		return pname;
	}


	public void setPname(String pname) {
		this.pname = pname;
	}


	public String getPaddress() {
		return paddress;
	}


	public void setPaddress(String paddress) {
		this.paddress = paddress;
	}


	public String getDob() {
		return dob;
	}


	public Person(int pid, String pname, String paddress, String dob2) {
		super();
		Pid = pid;
		this.pname = pname;
		this.paddress = paddress;
		this.dob = dob2;
	}


	public void setDob(String dob) {
		this.dob = dob;
	}


	protected String dob;
	

	
}
