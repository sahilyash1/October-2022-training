package OOPS_assingnmentsQuestion4;

import java.util.Scanner;

public class Area {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		int s1=sc.nextInt();
		int s2=sc.nextInt();
		int s3=sc.nextInt();
		CalculateArea ca=new CalculateArea();
		ca.areaOfRectangle(2, 3, 4);
		ca.areaOfSquare(2, 2, 2);
		ca.areaOfTriangle(2, 3, 4);
	}
}
class CalculateArea {

	

	void areaOfTriangle(double Length, double Width, double 
			Height) {
		double Triangle = Length * Width * Height;

		System.out.println("print area of tringle-" + Triangle);
	}

	void areaOfRectangle(double Length, double Height, double Width) {

		double Rectangle = Length * Width;

		System.out.println("print area of Rectangle-" + Rectangle);
	}

	void areaOfSquare(double Length, double Height, double Width) {

		double Square = Length * Length;
		System.out.println("print area of Square-" + Square);

	}


}
