package OOPS_assingnmentsQuestion5;

public abstract class A extends CalcAbc{

	@Override
	public void sum(int a, int b) {
		
		int c=a+b;
		System.out.println("Sum :"+c);
	

}
}
