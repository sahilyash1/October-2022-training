package OOPS_assingnmentsQuestion5;

public abstract class B extends A {
	public void sub(int a, int b)
    {
	   int c=a-b;
		System.out.println("Sub : "+c);
	   
	}

	public abstract void getNumbers(int number);

	

}
