package OOPS_assingnmentsQuestion5;

public abstract class C extends B {
	public void mul(int a, int b)
	  {
		  int c=a*b;
			System.out.println("Mul: "+c);
		  
	  }

}
