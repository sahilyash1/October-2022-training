package OOPS_assingnmentsQuestion5;

import java.util.Scanner;

public class D extends C {

	@Override
	public void div(int a, int b) {
		
		int c=a/b;
		System.out.println("Div :- "+c);
		
		
	}
	
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		CalcAbc cal=new D();
		System.out.println("The sum of two number is-");
		cal.sum(sc.nextInt(), sc.nextInt());
		
		System.out.println("The sub of two number is-");
		cal.sub(sc.nextInt(), sc.nextInt());
		
		System.out.println("The mul of two number is-");
		cal.mul(sc.nextInt(), sc.nextInt());
		
		System.out.println("The Div of two number is:");
		cal.div(sc.nextInt(), sc.nextInt());
		
		
	}

	@Override
	public void getNumbers(int number) {
		// TODO Auto-generated method stub
		
	}
		
	}
