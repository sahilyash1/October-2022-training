package OOPS_assingnmentsQuestion6;

public class AA {

	
	public void getNumbers(int number){
	
		System.out.println("Maximum of  3 ,4 and numbers");
	}

}
