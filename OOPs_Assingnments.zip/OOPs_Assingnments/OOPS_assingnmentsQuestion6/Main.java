package OOPS_assingnmentsQuestion6;

import java.util.Scanner;

import OOPS_assingnmentsQuestion5.B;
import OOPS_assingnmentsQuestion5.C;
import OOPS_assingnmentsQuestion5.D;

public class Main {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Find maximum of 3 ,4 or 5 for n number");

		int n = sc.nextInt();

		if (n == 3) {

			System.out.println("Enter 3 digit number");

			int number = sc.nextInt();

			BB cs = new BB();

			cs.getNumbers(number);
		}

		if (n == 4) {

			System.out.println("Enter 4 digit number");

			int number = sc.nextInt();

			CC css = new CC();

			css.getNumbers(number);
		}

		if (n == 5) {

			System.out.println("Enter the number");

			int number = sc.nextInt();

			DD csss = new DD();

			csss.getNumbers(number);
		}

	}
}
