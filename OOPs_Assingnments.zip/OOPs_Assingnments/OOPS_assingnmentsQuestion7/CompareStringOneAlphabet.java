package OOPS_assingnmentsQuestion7;

import java.util.Scanner;

public class CompareStringOneAlphabet implements StringComparison {
	
	
	public void stringCompare() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter first String:");
		String s1=sc.next();
		
		System.out.println("Enter second  String");
		String s2=sc.next();
		
		char ch1[]=s1.toCharArray();
		char ch2[]=s2.toCharArray();
		
		for(int i=0;i<ch1.length;i++)
		{
			for(int j=0;j<ch2.length;j++)
			{
				if(ch1[i]==ch2[j])
				{
					System.out.println("char  :"+ch1[i]+":"+ch2[j]);
				}
			}
		}
	}
	public static void main(String[] args) {
		StringComparison c = new CompareStringOneAlphabet();
		c.stringCompare();
	}


}
