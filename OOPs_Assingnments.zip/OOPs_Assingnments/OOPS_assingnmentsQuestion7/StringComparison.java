package OOPS_assingnmentsQuestion7;

public interface StringComparison  {
public void stringCompare();


}
