package OOPS_assingnmentsQuestion9;

public class FinalizeMethodClass {
	 public static void main(String[] args) {
		 Student s1=new Student(501);
		 Student s2=new Student(502);
		 Student s3=new Student(503);
		 Student s4=new Student(504);
		 Student s5=new Student(505);
	            
	            s2=null;
	            s5=null;
	            System.gc();
	            
	            for(int i=1;i<6;i++) {
	                String s="s"+i;
	                System.out.println(s+":"+s.hashCode());
	            }
	            System.out.println("s2="+s2);
	            System.out.println("s5="+s5);
	            
	    }

}
