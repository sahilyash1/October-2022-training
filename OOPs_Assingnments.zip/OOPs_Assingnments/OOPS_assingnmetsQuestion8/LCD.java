package OOPS_assingnmetsQuestion8;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LCD extends Electornics{
	public void laptopdetails() throws ParseException
	{
		Electornics e=new Electornics();
		e.setId(101);
		e.setSemicondoctorType("silicon");
		
		String dt = "04/07/1998";
		Date dateofManufacturing = new SimpleDateFormat("dd/MM/yyyy").parse(dt);
		
		System.out.println("Here we have LCD Details");
		System.out.println("Id: "+e.getId());
		System.out.println("semi_type: "+e.getSemicondoctorType());
		System.out.println("DOM: "+dt);
	}


}
