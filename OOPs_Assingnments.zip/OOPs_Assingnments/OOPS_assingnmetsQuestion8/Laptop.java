package OOPS_assingnmetsQuestion8;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Laptop extends Electornics{
	public void laptopdetails() throws ParseException
	{
		Electornics e=new Electornics();
		e.setId(101);
		e.setSemicondoctorType("silicon");
		
		String dt = "07/09/1998";
		Date dateofManufacturing = new SimpleDateFormat("dd/MM/yyyy").parse(dt);
		
		System.out.println("Here we have Lpatop Details:");
		System.out.println("Id: "+e.getId());
		System.out.println("semi_type: "+e.getSemicondoctorType());
		System.out.println("DOM: "+dt);
	}

}
