package OOPS_assingnmetsQuestion8;

import java.text.ParseException;

public class MainClass {
	
public static void main(String[] args) throws ParseException {
		
		Laptop lap=new Laptop();
		lap.laptopdetails();
		
		Mobile mob=new Mobile();
		mob.mobiledetails();
		
	
				

	}


}
