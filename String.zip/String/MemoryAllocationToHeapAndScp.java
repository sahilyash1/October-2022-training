package String;

public class MemoryAllocationToHeapAndScp {
	public static void main(String[] args)
	{
		
		String s1 = "sahil";
		String s2 = "sahil";

		String s3 = new String("rahul");
		String s4 = new String("rahul");
		
         System.out.println("s1 :"+s1.hashCode());
         System.out.println("s2 :"+s2.hashCode());
         System.out.println("s3 :"+s3.hashCode());
         System.out.println("s4 :"+s4.hashCode());
         
		//scp  
		if (s1 == s2)
		System.out.println("Memory allocated in SCP");
		else
		System.out.println("Memory Not allocated in SCP");

		//Heap
		if (s3 == s4)
		System.out.println("Memory allocated in Heap area");
		else
		System.out.println("Memory not allocated in Heap area");
		

	}

}
